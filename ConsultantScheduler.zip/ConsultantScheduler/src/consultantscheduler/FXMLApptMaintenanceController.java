/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultantscheduler;

import com.sun.javafx.collections.ElementObservableListDecorator;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Amanda
 */
public class FXMLApptMaintenanceController implements Initializable {

    
    @FXML
    TextField txtApptTitle;
    
    @FXML
    TextField txtCustName;
    
    @FXML
    DatePicker dpApptDate;
    
    
    @FXML
    TextField txtContact;
    
    @FXML
    TextField txtUrl;
    
    @FXML
    TextField txtLocation;
    
    @FXML
    TextArea taDescription;
    
    @FXML
    Button btnCancel;
    
    @FXML
    Button btnSave;
    
    @FXML
    TextField txtDate;
    
    @FXML
    TextField txtTime;
    
    String currentUser;

    
    Appointment currentAppt;
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        try{
        String query = "SELECT * from appointment WHERE appointmentid = ?";        
        DBConnection.createConn();
        PreparedStatement ps = DBConnection.conn.prepareStatement(query);
        ps.setInt(1,currentAppt.getAptID());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            //TODO - code RS next
            }
        }
        
        catch(Exception e){
                    
                     }
    }
    
    public void setUser(String user){
        
        currentUser = user;
        
    }
    
    
    public void btnSaveOnClick(){

        int year, month, apptDate, startHr = 0, endHr = 0, min=0;
        
      /*  switch (cbStartTime.getSelectionModel().getSelectedIndex()){
            case 0: startHr = 9; endHr = 10;
            break;
            case 1: startHr = 10; endHr = 11;
            break;
            case 2: startHr = 11; endHr = 12;
            break;
            case 3: startHr = 13; endHr = 14;
            break;
            case 4: startHr = 14; endHr = 15;
            break;
            case 5: startHr = 15; endHr = 16;
            break;
            default: 
                break;
        }
        
        year = dpApptDate.getValue().getYear();
        month = dpApptDate.getValue().getMonthValue();
        apptDate = dpApptDate.getValue().getDayOfMonth();
        */
        currentAppt.setCustName(txtCustName.getText());
        Boolean isNamePresent = true;
        if(txtCustName.getText().equals(""))
                {isNamePresent=false;}
        
        currentAppt.setTitle(txtApptTitle.getText());        
        Boolean isApptTitlePresent = true;
         if(txtApptTitle.getText().equals(""))
                {isApptTitlePresent=false;}        
        
        
         
        
         
        currentAppt.setContact(txtContact.getText());
        Boolean isContactPresent = true;
        if(txtContact.getText().equals("")){
            isContactPresent = false;
        }
        
        
        currentAppt.setLocation(txtLocation.getText());
        Boolean isLocationPresent = true;
         if(txtLocation.getText().equals(""))
                {isLocationPresent=false;}
         
        currentAppt.setURL(txtUrl.getText());
        Boolean isURLPresent = true;
         if(txtUrl.getText().equals(""))
                {isURLPresent=false;}
         
        currentAppt.setDescription(taDescription.getText());
        Boolean isDescriptionPresent = true;
         if(taDescription.getText().equals(""))
                {isDescriptionPresent=false;}
                
       
        
        String resultMsg;
        
        if(isNamePresent==false||isApptTitlePresent==false||isContactPresent==false||isLocationPresent==false||isURLPresent==false||isDescriptionPresent==false){
        resultMsg="Please enter a value for: ";
        
        if(isNamePresent==false){
            resultMsg+="\nName";
        }        
        if(isApptTitlePresent==false){
            resultMsg+="\nAppointment Title";
        }
        if(isContactPresent==false){
            resultMsg+="\nContact";
        }
        if(isLocationPresent==false){
            resultMsg+="\nLocation";
        }
        if(isURLPresent==false){
            resultMsg+="\nURL";
        }
        if(isDescriptionPresent==false){
            resultMsg+="\nDescription";
        }
        
            showErrorDialog(resultMsg);
        }
        
        
        else{
         
        try {
            DBConnection.createConn();
            String query = "UPDATE appointment SET title = ?, description = ?, location = ?, contact = ?, url = ?, lastUpdate = CURRENT_TIMESTAMP, lastUpdateBy = ? WHERE appointmentid = ?;";
            
            PreparedStatement statement = DBConnection.conn.prepareStatement(query);
   
            
            statement.setString(1, txtApptTitle.getText());
            statement.setString(2, taDescription.getText());
            statement.setString(3, txtLocation.getText());
            statement.setString(4, txtContact.getText());
            statement.setString(5, txtUrl.getText());
            statement.setString(6,currentUser);
            statement.setInt(7,currentAppt.getAptID());
            System.out.println(statement.toString());
            statement.executeUpdate();
           
            DBConnection.closeConnection();
            resultMsg = "Appointment updated successfully";
            showConfirmationDialog(resultMsg);
            returnToMainScreen();
            
            
        } catch (Exception ex) {
            resultMsg="Error: "+ex.getMessage();
            showConfirmationDialog(resultMsg);
            System.out.println("Error: "+ex.getMessage());
        }
    }
    
    }
   
    
        
    public void clearTextBoxes(){
        txtApptTitle.clear();
        txtContact.clear();
        txtCustName.clear();
        txtCustName.clear();
        taDescription.clear();
    }
    
    public void showConfirmationDialog(String msg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");      
        alert.setContentText(msg);
        alert.showAndWait();
    }
    
    public void showErrorDialog(String msg){
    
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error Dialog");
        alert.setHeaderText("Error");
        alert.setContentText(msg);
        alert.showAndWait();
    }
    
    @FXML
    public void btnCancelOnClick(ActionEvent event) throws IOException{
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Cancel?");

    Optional<ButtonType> result = alert.showAndWait();
    if (result.get() == ButtonType.OK){
    // ... user chose OK
    returnToCalendarPage();
    
    
    } else {
        alert.close();
    
    }
    
    }
    
    @FXML
    public void setAppointmentToEdit(Appointment _appointment){
        currentAppt=_appointment;
        txtCustName.setText(currentAppt.getCustName());
        txtApptTitle.setText(currentAppt.getTitle());
        txtDate.setText(currentAppt.getApptDate().toString());
        String startDetail, endDetail;
        
        
        if(currentAppt.getStartTime().getHour()==9||currentAppt.getStartTime().getHour()==10||currentAppt.getStartTime().getHour()==11){
            startDetail = "AM";
        }
        else{
            startDetail = "PM";
        }
        if (currentAppt.getEndTime().getHour()==10||currentAppt.getEndTime().getHour()==11){
            endDetail = "AM";
        }
        else{
            endDetail = "PM";
        }
        
        txtTime.setText(currentAppt.getStartTime().toString() + " " + startDetail +  " - " + currentAppt.getEndTime().toString() + " "+endDetail);
        txtContact.setText(currentAppt.getContact());
        txtUrl.setText(currentAppt.getURL());
        txtLocation.setText(currentAppt.getLocation());
        taDescription.setText(currentAppt.getDescription());
        
    }
    
    public void returnToMainScreen() throws IOException{
      
        Stage stage;
        stage= (Stage)btnSave.getScene().getWindow();

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLHomepage.fxml"));
        
        Parent root = (Parent)fxmlLoader.load();
        FXMLHomepageController doc = fxmlLoader.getController();
        doc.setCurrentUser(currentUser);
        //FXMLDocumentController doc = fxmlLoader.getController();
        //doc.setPartsList(partsList);
        //doc.setProductList(productsList);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
       public void returnToCalendarPage() throws IOException{
      
        Stage stage;
        stage= (Stage)btnSave.getScene().getWindow();

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLViewCalendar.fxml"));
        
        Parent root = (Parent)fxmlLoader.load();
        //FXMLDocumentController doc = fxmlLoader.getController();
        //doc.setPartsList(partsList);
        //doc.setProductList(productsList);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
